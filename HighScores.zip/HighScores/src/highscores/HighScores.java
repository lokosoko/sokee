/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package highscores;

import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author Sru
 */
public class NewClass {
    
}
package highscores;

import java.io.*;
import java.util.Scanner;
public class HighScores {
 
    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    static String newName;
    static int lifeline;
    static int Crctans;
    static int quesansw;
    static int ar;
    static int u = 12;
    static int l = -12;
    static int menu;
    static int[] prevScore = new int[10];
    static Scanner userInput = new Scanner(System.in);
 
    public static void main(String args[]) throws IOException {
        //menu
        System.out.println("Ready for some Math Challenge?");
        do {
            menu = 0;
            newName = "abc";
            System.out.println("Press 1: START,\nPress 2: INSTRUCTIONS,\n"
                    + "Press 3: EXIT.");
            String choose = userInput.nextLine();
            menu = Integer.parseInt(choose);
            if (menu == 1) {
                startGame();
            } else if (menu == 2) {
                System.out.println("Welcome to the Math Game. In this program."
                + "In this game we will test your math skills\n You have to answer some maths questions."
                + "\nEnter your answer and it will check if its correct or not. You have 3 lifelines. Game will end after your\n lifelines end."
                + "At the end of the game, your score (the number of questions you got right), and your name will be taken.");
                } else if (menu == 3) {
                System.out.println("Thanks");
            }
        } while (menu != 1 && menu != 3);
    }//main method
 
    public static int startGame() throws IOException //a method that initializes a new game
    {
       
        lifeline = 3;
        Crctans = 0;
        quesansw = 0;
        do {
            System.out.println("Your lives left: " + lifeline + "\n You have Answered: " + quesansw);
            NewQuesGenerator();
            System.out.print("Answer: ");
            String answer1 = userInput.nextLine();
            try {
                int answer = Integer.parseInt(answer1);
                    if (answer != ar) {
                    lifeline--;
                    quesansw++;
                    System.out.println("Your answer is wrong."
                            + " The correct answer is" + ar + ".");
                } else {
                    quesansw++;
                    Crctans++;
                    System.out.println("Correct! +1 Point!");
                    System.out.println("Correct Answers: " + Crctans);
                }
            }
            catch (Exception e) {
                System.out.println("Please enter a valid number.");
            }
        } while (lifeline > 0);
        endGame(Crctans);
        return Crctans;
    }
    
 
    public static int NewQuesGenerator() // a method that displays a random arithmetic question
    {
        int num1 = Num(u, l);
        int num2 = Num(u, l);
        int operator = 1 + (int) (Math.random() * ((4 - 1) + 1));
        if (operator == 1) {
            System.out.println("question : " + num1 + " + " + num2);
            ar = num1 + num2;
        } else if (operator == 2) {
            System.out.println("question : " + num1 + " - " + num2);
            ar = num1 - num2;
        } else if (operator == 3) {
            System.out.println("question :" + num1 + " X " + num2);
            ar = num1 * num2;
        } else if (operator == 4) {
            do {
                num2 = Num(u, l);
            } while (num2 == 0);
            System.out.println("question" + num1 + " / " + num2);
            ar = num1 / num2;
            Math.floor(ar);
        }
        return (ar);
    }
    public static String endGame(int answersCorrect) throws IOException // a method that tells the user the game is over
    {
        System.out.println("GAME OVER!");
        System.out.println("Congratulations, your score " + answersCorrect);
        System.out.println("Please enter your name: ");
        newName = userInput.nextLine();
        System.out.println("Thanks for playing " + newName + "!");
        return (newName);
    }
 
    public static int Num(int u, int l) //a method that makes a random number between the upper and lower ranges
    {
        int num3 = (-12) + (int) (Math.random() * ((12 - -12) + 1));
        return num3;
    }

    private static void start() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 
} //MadMath class